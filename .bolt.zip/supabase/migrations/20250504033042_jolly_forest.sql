/*
  # Update Certificate Date
  
  1. Changes
    - Update fecha_certificado for certificate ID 1746328037
    - Change date from 2025-03-14 to 2025-03-13
*/

UPDATE certificates 
SET fecha_certificado = '2025-03-13'
WHERE id = 1746328037;