// Simple SVG logo as data URL
export const DUOC_LOGO_URL = '/images/duoc-logo.png';

// White version of the logo
export const DUOC_LOGO_WHITE_URL = '/images/logo-duoc-blanco.png';

// Certificate signature image
export const SIGNATURE_IMAGE_URL = '/images/firma.png';